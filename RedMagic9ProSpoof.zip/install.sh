SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
  ui_print "*******************************"
  ui_print "ZTE Nubia Red Magic 9 Pro [Spoof]"
  ui_print "By @ussefayman_"
  ui_print "Channel: @InsideAlexWorld"
  ui_print "Unlock 120FPS in CODM"
  ui_print "*******************************"
}

MOD_EXTRACT() {
  unzip -o "$ZIPFILE" system/* -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}